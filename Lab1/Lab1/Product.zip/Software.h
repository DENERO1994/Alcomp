#ifndef Software_h
#define Software_h
#include "Product.h"
using namespace std;

class Software : public Product
{
public:
	Software(double);
};
#endif