#include "Software.h"
using namespace std;

Software::Software(double price):Product(price)
{
	netPrice = price;
}
